import os
import sys
import random
import time
import firebase_admin
from firebase_admin import credentials, firestore

# -------------------------
# HELPER FUNCTION FOR PATHS (PyInstaller-compatible)
# -------------------------
def get_path(filename):
    """Return correct path whether running from script or PyInstaller .exe"""
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, filename)
    return os.path.join(os.path.dirname(__file__), filename)

# -------------------------
# FIREBASE SETUP
# -------------------------
cred_path = get_path("gambling-io-firebase-adminsdk-fbsvc-8a879b1d14.json")
cred = credentials.Certificate(cred_path)
firebase_admin.initialize_app(cred)

db = firestore.client()
starting_balance = 1000
interest_rate = 0.10

# -------------------------
# DATABASE FUNCTIONS
# -------------------------
def get_user(username):
    doc = db.collection("users").document(username).get()
    if doc.exists:
        return doc.to_dict()
    return None

def save_user(username, data):
    db.collection("users").document(username).set(data)

def get_house():
    doc = db.collection("house").document("stats").get()
    return doc.to_dict()

def update_profit(amount, game):
    db.collection("house").document("stats").update({
        "profit": firestore.Increment(amount),
        f"game_profits.{game}": firestore.Increment(amount)
    })

# -------------------------
# LOGIN SYSTEM
# -------------------------
def login():
    while True:
        print("Do you have an account? (Y/N)")
        choice = input().upper()

        if choice == "Y":
            username = input("Username: ")
            admin_doc = db.collection("admin").document("credentials").get().to_dict()

            if username == admin_doc["username"]:
                p1 = input("Admin password 1: ")
                p2 = input("Admin password 2: ")
                if p1 == admin_doc["password1"] and p2 == admin_doc["password2"]:
                    print("Admin access granted.")
                    return "admin"
                else:
                    print("Incorrect admin passwords.")
                    continue

            user_data = get_user(username)
            if user_data:
                print(f"Welcome {username}!")
                return username
            else:
                print("User not found.")

        elif choice == "N":
            username = input("Create username: ")
            if get_user(username):
                print("Username already exists.")
            else:
                new_user = {"balance": starting_balance, "wins": 0, "losses": 0, "loan": 0}
                save_user(username, new_user)
                print("Account created!")
        else:
            print("Invalid input.")

# -------------------------
# HIGH-LOW GAME
# -------------------------
def highLowGame(username):
    print("\n--- High-Low Game ---")
    while True:
        user = get_user(username)
        print(f"Balance: ${user['balance']}")
        try:
            bet = int(input("Enter your bet: "))
        except:
            print("Invalid number.")
            continue
        if bet <= 0 or bet > user["balance"]:
            print("Invalid bet.")
            continue
        old_card = random.randint(1, 9)
        print(f"First card: {old_card}")
        guess = input("Higher or Lower? (H/L): ").upper()
        new_card = random.randint(1, 9)
        print(f"Next card: {new_card}")
        if (guess == "H" and new_card > old_card) or (guess == "L" and new_card < old_card):
            user["balance"] += bet
            user["wins"] += 1
            update_profit(-bet, "high_low")
            print(f"You win! New balance: ${user['balance']}")
        else:
            user["balance"] -= bet
            user["losses"] += 1
            update_profit(bet, "high_low")
            print(f"You lose! New balance: ${user['balance']}")
        save_user(username, user)
        if user["balance"] <= 0:
            print("You're out of money!")
            return
        if input("Play again? (Y/N): ").upper() != "Y":
            return

# -------------------------
# SLOTS GAME
# -------------------------
def slotsGame(username):
    # You could replace these with images later if desired
    symbols = ["🍒", "🍋", "🔔", "💎"]
    print("\n--- Slot Machine ---")
    while True:
        user = get_user(username)
        print(f"Balance: ${user['balance']}")
        try:
            bet = int(input("Enter your bet: "))
        except:
            print("Invalid number")
            continue
        if bet <= 0 or bet > user["balance"]:
            print("Invalid bet")
            continue

        final_spin = [random.choice(symbols) for _ in range(3)]
        print("Spinning...", end="\r")
        for i in range(3):
            for _ in range(5):
                preview = [random.choice(symbols) for _ in range(3)]
                print(" | ".join(preview), end="\r")
                time.sleep(0.1)
            preview = final_spin[:i+1] + [random.choice(symbols) for _ in range(2-i)]
            print(" | ".join(preview), end="\r")
            time.sleep(0.3)
        print(" | ".join(final_spin))

        if final_spin[0] == final_spin[1] == final_spin[2]:
            winnings = bet*5
            user["balance"] += winnings
            user["wins"] += 1
            update_profit(-winnings,"slots")
            print(f"JACKPOT! You win ${winnings}")
        elif final_spin[0] == final_spin[1] or final_spin[1] == final_spin[2]:
            winnings = bet*2
            user["balance"] += winnings
            user["wins"] += 1
            update_profit(-winnings,"slots")
            print(f"Nice! You win ${winnings}")
        else:
            user["balance"] -= bet
            user["losses"] += 1
            update_profit(bet,"slots")
            print("No match. You lose.")

        save_user(username,user)
        if user["balance"] <= 0:
            print("You're out of money!")
            return
        if input("Spin again? (Y/N): ").upper() != "Y":
            return

# -------------------------
# BLACKJACK, COIN FLIP, BANK, ADMIN, MAIN_MENU
# -------------------------
# (Keep everything as in your previous full code)
# Just make sure if you ever load assets/images, you wrap them in get_path(), e.g.:
# img_path = get_path("slot_image.png")

# -------------------------
# MAIN PROGRAM
# -------------------------
def main():
    while True:
        username = login()
        main_menu(username)
        print("Returning to login screen...\n")

if __name__=="__main__":
    main()
